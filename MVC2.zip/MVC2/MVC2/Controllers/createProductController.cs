﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC2.Controllers
{
    public class createProductController : Controller
    {
        //
        // GET: /createProduct/

        public ActionResult Index()
        {
            try
            {
                string Query = "select idProduct, Name from products;";
                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                //  MyConn2.Open();  
                //For offline connection we weill use  MySqlDataAdapter class.  
                MySqlDataAdapter MyAdapter = new MySqlDataAdapter();
                MyAdapter.SelectCommand = MyCommand2;
                DataTable dTable = new DataTable();
                MyAdapter.Fill(dTable);
                dataGridView1.DataSource = dTable; // here i have assign dTable object to the dataGridView1 object to display data.               
                // MyConn2.Close();  
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }  
            return View();
        }

        //
        // GET: /createProduct/Details/5

        public ActionResult Details(int id)
        {
            return View();
        }

        //
        // GET: /createProduct/Create

        public ActionResult Create(string Product)
        {
            try
            {
                string MyConnection2 = "datasource=localhost;port=3307;username=root;password=root";
                string Query = "insert into product (Name) values('"+ Product +"');";
                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();     // Here our query will be executed and data saved into the database.  
                Console.Write("Save Data");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            }  
            return View();
        }

        //
        // POST: /createProduct/Create

        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }

        //
        // GET: /createProduct/Edit/5

        public ActionResult Edit(int id)
        {
            return View();
        }

        //
        // POST: /createProduct/Edit/5

        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection, string namechange, string name)
        {
            try
            {
                // TODO: Add update logic here
                    string Query = "update Product set name='"+ namechange +"' where name='" + name + "';";
                    MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                    MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                    MySqlDataReader MyReader2;
                    MyConn2.Open();
                    MyReader2 = MyCommand2.ExecuteReader();
                    Console.Write("Data Updated");
                    while (MyReader2.Read())
                    {
                    }
                    MyConn2.Close();//Connection closed here  
                catch (Exception ex)
                {
                    Console.Write(ex.Message);
                }
                return RedirectToAction("Index");
             }
            catch
            {
                return View();
            }
        }

        //
        // GET: /createProduct/Delete/5

        public ActionResult Delete(int id, string name)
        {
            try
            {
                string Query = "delete from products where name='" + name + "' and idProduct= " + id + ";";
                MySqlConnection MyConn2 = new MySqlConnection(MyConnection2);
                MySqlCommand MyCommand2 = new MySqlCommand(Query, MyConn2);
                MySqlDataReader MyReader2;
                MyConn2.Open();
                MyReader2 = MyCommand2.ExecuteReader();
                Console.Write("Data Deleted");
                while (MyReader2.Read())
                {
                }
                MyConn2.Close();
            }
            catch (Exception ex)
            {
                Console.Write(ex.Message);
            } 
            return View();
        }

        //
        // POST: /createProduct/Delete/5

        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
